package com.sola.v2ex_android.util;

/**
 * Created by wei on 2016/10/26.
 */

public class Constants {

    public static String V2EX_URL = "https://www.v2ex.com/api/";

    public static String V2EX_BASE_URL = "https://www.v2ex.com/";


    public static String makeUserLogo(String url){
        return "http:" + url;
    }

}
