package com.sola.v2ex_android.model;

import java.util.List;

/**
 * Created by wei on 2016/11/28.
 */

public class MyFollowingTopicDetial {

    public String avatar;
    public String userName;
    public String title;
    public String content;
    public String publishTime;
    public int replies_count;

    public List<Replies> replies;
}
