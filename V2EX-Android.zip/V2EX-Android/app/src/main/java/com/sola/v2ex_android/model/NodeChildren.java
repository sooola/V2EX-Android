package com.sola.v2ex_android.model;

/**
 * Created by wei on 2016/10/28.
 */

public class NodeChildren {

    public String title;
}
