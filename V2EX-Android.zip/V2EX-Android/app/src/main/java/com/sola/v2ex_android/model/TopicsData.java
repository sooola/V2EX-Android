package com.sola.v2ex_android.model;

import java.util.List;

/**
 * Created by wei on 2016/10/26.
 */

public class TopicsData {

    public  List<Topics> hotTopics;

    public List<Topics> latestTopics;

    public List<Topics> allTopics;
}
