package com.sola.v2ex_android.ui.base.callback;

import android.view.View;

/**
 * Created by wei on 2016/10/18.
 */

public interface OnItemClickListener {
    void onItemClick(View view, int position);
}
