package com.sola.v2ex_android.model;

/**
 * Created by wei on 2016/11/15.
 */

public class MyFollowing {

    public String userName;
    public String title;
    public String userIconUrl;
    public String nodeName;
    public String commentCount;
    public String topicId;

}
