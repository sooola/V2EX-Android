package com.sola.v2ex_android.model;

import java.util.List;

/**
 * Created by wei on 2016/10/28.
 */

public class NodeGroup {

    public String groupTitle;

    public List<String> childrenTitleList;

}
