package com.sola.v2ex_android.event;

/**
 * Created by wei on 2016/11/14.
 */

public class UserLogoutEvent {
}
