# V2EX-Android

[fir.im下载地址](http://fir.im/sooooola)  


V2EX的Android客户端， RxJava & Retrofit & Glide   
数据来源 https://www.v2ex.com/
因官方API说明有些缺少的部分，也写了份API 说明 https://github.com/sooola/V2EX-API ，方便大家查阅

相关文章 http://www.jianshu.com/p/24c0b44f3d0b

#TODO  
话题创建  
话题回复  
主题收藏  
关注用户  
签到

#Screenshots
![image](https://github.com/sooola/V2EX-Android/blob/master/screenshots/s0.png)
![image](https://github.com/sooola/V2EX-Android/blob/master/screenshots/s1.png)
![image](https://github.com/sooola/V2EX-Android/blob/master/screenshots/s2.png)
![image](https://github.com/sooola/V2EX-Android/blob/master/screenshots/s3.png)
![image](https://github.com/sooola/V2EX-Android/blob/master/screenshots/s4.png)
![image](https://github.com/sooola/V2EX-Android/blob/master/screenshots/s5.png)
